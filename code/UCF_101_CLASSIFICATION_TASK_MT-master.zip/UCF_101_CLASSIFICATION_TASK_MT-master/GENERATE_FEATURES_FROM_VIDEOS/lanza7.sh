cd /home/jjorge/script; ./process_videos.sh part_7
